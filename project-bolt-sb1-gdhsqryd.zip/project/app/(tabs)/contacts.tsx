import { View, Text, FlatList, StyleSheet, Pressable } from 'react-native';
import { User } from 'lucide-react-native';

const mockContacts = [
  { id: '1', name: 'John Doe', status: 'online' },
  { id: '2', name: 'Jane Smith', status: 'offline' },
  { id: '3', name: 'Mike Johnson', status: 'online' },
];

export default function ContactsScreen() {
  const renderContactItem = ({ item }) => (
    <Pressable style={styles.contactItem}>
      <View style={styles.avatar}>
        <User size={24} color="#60A5FA" />
      </View>
      <View style={styles.contactInfo}>
        <Text style={styles.contactName}>{item.name}</Text>
        <Text style={[
          styles.status,
          { color: item.status === 'online' ? '#34D399' : '#9CA3AF' }
        ]}>
          {item.status}
        </Text>
      </View>
    </Pressable>
  );

  return (
    <View style={styles.container}>
      <FlatList
        data={mockContacts}
        renderItem={renderContactItem}
        keyExtractor={(item) => item.id}
        contentContainerStyle={styles.listContent}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#111827',
  },
  listContent: {
    padding: 16,
  },
  contactItem: {
    flexDirection: 'row',
    padding: 12,
    backgroundColor: '#1F2937',
    borderRadius: 12,
    marginBottom: 8,
    alignItems: 'center',
  },
  avatar: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: '#374151',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  contactInfo: {
    flex: 1,
  },
  contactName: {
    fontSize: 16,
    fontWeight: '600',
    color: '#FFFFFF',
    marginBottom: 4,
  },
  status: {
    fontSize: 14,
  },
});