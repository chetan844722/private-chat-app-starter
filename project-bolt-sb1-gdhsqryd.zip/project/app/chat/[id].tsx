import { useState } from 'react';
import { View, Text, TextInput, StyleSheet, FlatList, Pressable } from 'react-native';
import { useLocalSearchParams } from 'expo-router';
import { Image } from 'expo-image';
import * as DocumentPicker from 'expo-document-picker';
import Animated, { FadeInRight, FadeInLeft } from 'react-native-reanimated';
import { Send, Paperclip, Image as ImageIcon } from 'lucide-react-native';

const mockMessages = [
  { 
    id: '1', 
    text: 'Hey, how are you?', 
    sent: true, 
    time: '10:30 AM',
    type: 'text'
  },
  { 
    id: '2', 
    text: 'I\'m good, thanks! How about you?', 
    sent: false, 
    time: '10:31 AM',
    type: 'text'
  },
  {
    id: '3',
    text: 'Check out this photo!',
    sent: true,
    time: '10:32 AM',
    type: 'image',
    imageUrl: 'https://images.unsplash.com/photo-1501854140801-50d01698950b?w=800&auto=format&fit=crop&q=80'
  },
];

export default function ChatScreen() {
  const { id } = useLocalSearchParams();
  const [message, setMessage] = useState('');

  const handleSendMessage = () => {
    if (message.trim()) {
      // TODO: Implement message sending with Supabase
      setMessage('');
    }
  };

  const handleAttachment = async () => {
    try {
      const result = await DocumentPicker.getDocumentAsync({
        type: '*/*',
        copyToCacheDirectory: false,
      });

      if (result.type === 'success') {
        // TODO: Implement file upload with Supabase Storage
        console.log('Selected file:', result.uri);
      }
    } catch (error) {
      console.error('Error picking document:', error);
    }
  };

  const renderMessage = ({ item }) => {
    const AnimatedMessage = item.sent ? 
      Animated.createAnimatedComponent(View) : 
      Animated.createAnimatedComponent(View);

    const enteringAnimation = item.sent ? FadeInRight : FadeInLeft;

    return (
      <AnimatedMessage 
        entering={enteringAnimation.delay(200)}
        style={[
          styles.messageContainer,
          item.sent ? styles.sentMessage : styles.receivedMessage
        ]}>
        {item.type === 'image' ? (
          <View>
            <Image
              source={item.imageUrl}
              style={styles.messageImage}
              contentFit="cover"
              transition={500}
            />
            <Text style={styles.messageTime}>{item.time}</Text>
          </View>
        ) : (
          <>
            <Text style={styles.messageText}>{item.text}</Text>
            <Text style={styles.messageTime}>{item.time}</Text>
          </>
        )}
      </AnimatedMessage>
    );
  };

  return (
    <View style={styles.container}>
      <FlatList
        data={mockMessages}
        renderItem={renderMessage}
        keyExtractor={(item) => item.id}
        contentContainerStyle={styles.messagesList}
      />
      <View style={styles.inputContainer}>
        <Pressable style={styles.attachButton} onPress={handleAttachment}>
          <Paperclip size={24} color="#60A5FA" />
        </Pressable>
        <TextInput
          style={styles.input}
          placeholder="Type a message..."
          placeholderTextColor="#9CA3AF"
          value={message}
          onChangeText={setMessage}
          multiline
        />
        <Pressable 
          style={[styles.sendButton, message.trim() ? styles.sendButtonActive : null]}
          onPress={handleSendMessage}>
          <Send size={24} color={message.trim() ? '#FFFFFF' : '#60A5FA'} />
        </Pressable>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#111827',
  },
  messagesList: {
    padding: 16,
  },
  messageContainer: {
    maxWidth: '80%',
    padding: 12,
    borderRadius: 16,
    marginBottom: 8,
  },
  sentMessage: {
    alignSelf: 'flex-end',
    backgroundColor: '#3B82F6',
  },
  receivedMessage: {
    alignSelf: 'flex-start',
    backgroundColor: '#1F2937',
  },
  messageText: {
    color: '#FFFFFF',
    fontSize: 16,
  },
  messageImage: {
    width: 200,
    height: 200,
    borderRadius: 12,
    marginBottom: 4,
  },
  messageTime: {
    color: '#D1D5DB',
    fontSize: 12,
    marginTop: 4,
    alignSelf: 'flex-end',
  },
  inputContainer: {
    flexDirection: 'row',
    padding: 16,
    backgroundColor: '#1F2937',
    alignItems: 'center',
    gap: 12,
  },
  attachButton: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: '#374151',
    justifyContent: 'center',
    alignItems: 'center',
  },
  input: {
    flex: 1,
    backgroundColor: '#374151',
    borderRadius: 24,
    padding: 12,
    color: '#FFFFFF',
    maxHeight: 100,
  },
  sendButton: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: '#374151',
    justifyContent: 'center',
    alignItems: 'center',
  },
  sendButtonActive: {
    backgroundColor: '#3B82F6',
  },
});